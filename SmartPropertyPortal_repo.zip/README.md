# 🏠 Smart Property Portal

A Salesforce-based Property Management and Booking System built with **Apex**, **Lightning Web Components (LWC)**, **Flows**, and **Salesforce DX**.  
This project demonstrates complete end-to-end functionality including **Property Listings**, **Search Filters**, **Visit Scheduling**, **Flow Automation**, **External SMS Integration**, and **Reports/Dashboards**.

---

## 📖 Project Overview
The **Smart Property Portal** allows users to:
- Browse available properties.
- Filter by location and price.
- View property galleries with images.
- Schedule visits via Flow.
- Receive SMS notifications on bookings (via external API).
- View reports and dashboards for property trends.

---

## 🏗️ Tech Stack
- **Salesforce DX (SFDX)**
- **Scratch Orgs**
- **Apex Classes & Triggers**
- **Lightning Web Components (LWC)**
- **Flows (Screen & Auto-launched)**
- **Named Credentials + Callouts**
- **Reports & Dashboards**

---

## 🚀 Setup Instructions

### 1. Clone the repository
```bash
git clone https://github.com/your-username/SmartPropertyPortal.git
cd SmartPropertyPortal
```

### 2. Authenticate Dev Hub
```bash
sfdx auth:web:login -d -a DevHub
```

### 3. Create Scratch Org
```bash
sfdx force:org:create -s -f config/project-scratch-def.json -a SPPDev
```

### 4. Push Source
```bash
sfdx force:source:push -u SPPDev
```

### 5. Assign Permission Set (if created)
```bash
sfdx force:user:permset:assign -n SPP_Agent_Perms -u SPPDev
```

### 6. Import Sample Data
```bash
sfdx force:data:bulk:upsert -s Property__c -f data/Property.csv -i External_Id__c -w 10 -u SPPDev
```
For Contacts → Use **Data Import Wizard** in Salesforce Setup.

### 7. Open Org
```bash
sfdx force:org:open -u SPPDev
```

---

## 🎯 Features
- **Property Management**
  - Custom objects: Property__c, Booking__c, Property_Visit__c, Property_Image__c
  - Data import via CSV

- **Search & Gallery**
  - LWC for property gallery
  - Search filters by City and Price

- **Visit Scheduling**
  - Flow with DateTime validation
  - Integrated with LWC button

- **Integration**
  - Named Credentials for external SMS/Email API
  - Apex Queueable/Future callouts

- **Reports & Dashboards**
  - Properties by City
  - Visits by Agent
  - Booking conversions

---

## 📂 Repository Structure
```
SmartPropertyPortal/
├── README.md
├── docs/               # Phase-wise documentation
│   ├── Phase1-Setup.md
│   ├── Phase2-OrgSetup.md
│   ├── Phase3-DataModel.md
│   ├── Phase4-Flows.md
│   ├── Phase5-Apex.md
│   ├── Phase6-LWC.md
│   ├── Phase7-Integration.md
│   ├── Phase8-DataDeployment.md
│   ├── Phase9-Reports.md
│   └── Phase10-Demo.md
├── screenshots/        # Project screenshots (place your images here)
├── data/               # Sample CSV data
│   ├── Property.csv
│   └── Contact.csv
└── force-app/          # Salesforce DX source code (add your code here)
```

---

## 📸 Screenshots
Place your screenshots inside the `screenshots/` folder and update docs accordingly.

---

## 👨‍💻 Contributors
- **Anchal** — Roll No: 0206RA221014  
- **Pranav Singh** — Roll No: 0206RA221043  
- **Sinku Singh** — Roll No: 0206RA221065  
- **Samyak Jain** — Roll No: 065206RA221056  

---

## 📅 Project Timeline
- **Phase 1–3**: Setup & Data Model  
- **Phase 4–5**: Flows & Apex Controllers  
- **Phase 6–7**: LWC Development & Integration  
- **Phase 8–9**: Data Management & Reports  
- **Phase 10**: Demo & Submission

---

## 🏆 Final Demo
- Navigate to a Property record → view gallery LWC.  
- Click **Book Visit** → Flow opens → Visit record created.  
- SMS notification sent via integration.  
- Reports/Dashboard updated in real time.
