# Phase 6: Lightning Web Components

## 🎯 Objective
Create property gallery and search LWCs.

## 📝 Components
- `propertyGallery`
- `searchProperties`
- `bookingWidget`

## 📸 Screenshot
_Screenshot of LWC gallery on record page._
![LWC Screenshot](../screenshots/phase6_lwc_ui.png)
