# Phase 5: Apex Classes

## 🎯 Objective
Develop Apex controllers and test classes.

## 📝 Example
**PropertyController.cls**
```apex
public with sharing class PropertyController {
    @AuraEnabled(cacheable=true)
    public static List<Property__c> searchProperties(String city) {
        return [SELECT Id, Name, Price__c, City__c, Status__c FROM Property__c WHERE City__c = :city];
    }
}
```

## 📸 Screenshot
_Screenshot of Apex class in VS Code._
![Apex Screenshot](../screenshots/phase5_apex_test.png)
