# Phase 1: Project Setup & Authentication

## 🎯 Objective
Setup Salesforce DX project, connect to Dev Hub, and create a scratch org.

## 📝 Steps
1. Install **Salesforce CLI**, **VS Code**, **Salesforce Extension Pack**.
2. Create new SFDX project:
```bash
sfdx force:project:create -n SmartPropertyPortal
cd SmartPropertyPortal
```
3. Authenticate Dev Hub:
```bash
sfdx auth:web:login -d -a DevHub
```
4. Create scratch org:
```bash
sfdx force:org:create -s -f config/project-scratch-def.json -a SPPDev
```
5. Open org:
```bash
sfdx force:org:open -u SPPDev
```

## 📸 Screenshot
_Add terminal screenshot after project creation + org open._
![Setup Screenshot](../screenshots/phase1_setup.png)
