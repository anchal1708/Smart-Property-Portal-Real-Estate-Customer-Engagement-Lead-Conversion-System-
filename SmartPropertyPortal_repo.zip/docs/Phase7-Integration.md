# Phase 7: Integration & External Access

## 🎯 Objective
Connect Salesforce with external SMS/Email API.

## 📝 Steps
1. Setup → Named Credentials → created **Twilio_SMS**.
2. Apex Queueable class → SmsService.cls.
3. Test class → MockTwilioResponse.cls with HttpCalloutMock.

## 📸 Screenshot
_Screenshot of Named Credential configuration._
![Integration Screenshot](../screenshots/phase7_named_credential.png)
