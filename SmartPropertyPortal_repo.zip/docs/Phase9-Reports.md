# Phase 9: Reports & Dashboards

## 🎯 Objective
Visualize property and booking trends.

## 📝 Reports
- Properties by City
- Bookings by Agent

## 📸 Screenshot
_Dashboard screenshot._
![Reports Screenshot](../screenshots/phase9_dashboard.png)
