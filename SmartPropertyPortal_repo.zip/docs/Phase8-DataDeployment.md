# Phase 8: Data Management & Deployment

## 🎯 Objective
Import sample data for testing.

## 📝 Steps
- Created `data/Property.csv` and `data/Contact.csv`.
- Imported Contacts using Data Import Wizard.
- Upserted Properties:
  ```bash
  sfdx force:data:bulk:upsert -s Property__c -f data/Property.csv -i External_Id__c -w 10 -u SPPDev
  ```

## 📸 Screenshot
_Screenshot of Data Import Wizard / CLI output._
![Data Deployment Screenshot](../screenshots/phase8_data_upload.png)
