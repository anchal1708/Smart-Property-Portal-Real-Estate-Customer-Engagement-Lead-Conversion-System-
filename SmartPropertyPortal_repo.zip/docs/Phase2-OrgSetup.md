# Phase 2: Org Setup & Configuration

## 🎯 Objective
Define roles, profiles, permission sets, and organization-wide defaults.

## 📝 Steps
- Setup → Roles → Created **CEO > Manager > Agent** hierarchy.
- Setup → Profiles → Cloned Standard User → created `Property Manager`, `Sales Agent`.
- Created permission sets for property access.
- Set OWD to **Private** for custom objects.

## 📸 Screenshot
_Role hierarchy screenshot._
![Roles Screenshot](../screenshots/phase2_roles.png)
