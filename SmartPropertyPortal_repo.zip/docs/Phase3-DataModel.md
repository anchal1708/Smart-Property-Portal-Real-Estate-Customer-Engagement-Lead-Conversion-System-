# Phase 3: Data Modeling & Relationships

## 🎯 Objective
Create custom objects, fields, and relationships.

## 📝 Objects
- **Property__c** → Name, Price__c, City__c, Status__c, Bedrooms__c, Bathrooms__c, Address__c
- **Property_Image__c** → child object with Master-Detail to Property__c
- **Booking__c**
- **Property_Visit__c**

## 📸 Screenshot
_Object Manager → Property__c fields screenshot._
![Data Model Screenshot](../screenshots/phase3_objects.png)
