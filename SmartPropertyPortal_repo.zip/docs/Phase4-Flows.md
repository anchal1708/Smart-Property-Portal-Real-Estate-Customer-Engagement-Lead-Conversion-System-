# Phase 4: Flows & Automation

## 🎯 Objective
Implement automation for visit scheduling.

## 📝 Steps
1. Setup → Flows → New → Screen Flow.
2. Added Lookup for Property, DateTime field for visit date.
3. Decision → validate date ≥ current date.
4. Create record → Property_Visit__c.
5. Optional → Apex Action (BookingService.checkAvailability).

## 📸 Screenshot
_Screenshot of Flow builder._
![Flow Screenshot](../screenshots/phase4_flow.png)
